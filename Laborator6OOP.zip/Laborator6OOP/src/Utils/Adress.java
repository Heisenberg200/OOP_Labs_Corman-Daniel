package Utils;

public class Adress {
	  public String house;
	    public String street;
	    public String city;
	    public String country;
	    public String postalCode;
}
