package Staff;

public class Technician extends TechnicalStaff{

}
