package Staff;

public class FrontDescStaff extends AdministrativeStaff {

}
