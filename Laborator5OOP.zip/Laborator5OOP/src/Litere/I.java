package Litere;

public class I extends H{
	protected String i;
	public I(String string) {
		super();
		this.i = string;
	}
	public I() {
		this.i = "i";
	}
@Override
public String toString() {
	return super.toString() + "\nI{" + "i='" + '\'' + ", x= concatinat" + x + '}';
}
}
