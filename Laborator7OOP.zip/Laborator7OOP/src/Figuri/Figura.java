package Figuri;

public abstract class Figura {
	public abstract float getPerimetru();
    public abstract float getAria();
    //abstract float getVolume();
}
