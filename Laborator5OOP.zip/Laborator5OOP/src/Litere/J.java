package Litere;

public class J extends I{
	protected String j;
	public J(String string) {
		super();
		this.j = string;
	}
public J() {
	this.j  ="j";
}

@Override
public String toString() {
	return super.toString() + "\nJ{" + "j ='" + '\'' + ", x= concatinat" + x + '}';
}





}
