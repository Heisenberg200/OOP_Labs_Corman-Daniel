package Staff;

public class SurgicalTachnologist extends Technologist{

}
