package Utils;

public class Phone {
	  public String dialingCode; 
	    public String number;
}
