package Staff;

public class Surgeon extends Doctor {

}
