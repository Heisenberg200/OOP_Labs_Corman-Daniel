package Staff;

public class Nurse extends OperationsStaff {

}
