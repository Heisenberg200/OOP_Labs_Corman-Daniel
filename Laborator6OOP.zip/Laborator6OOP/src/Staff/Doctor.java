package Staff;

import java.util.ArrayList;

public class Doctor extends OperationsStaff {
    public ArrayList<String> speciality = new ArrayList<String>();
    public ArrayList<String> locations = new ArrayList<String>();
}