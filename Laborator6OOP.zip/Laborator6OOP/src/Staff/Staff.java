package Staff;

import Main.Person;
import java.util.ArrayList;
import java.util.Date;

public class Staff extends Person {
    public Date joined;
    public ArrayList<String> education = new ArrayList<String>();
    public ArrayList<String> certification = new ArrayList<String>();
    public ArrayList<String> languages = new ArrayList<String>();
}
