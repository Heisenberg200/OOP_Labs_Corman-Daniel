package Staff;

public class Technologist {

}
