package Utils;

import java.util.ArrayList;

public class History {
	public ArrayList<HistoryData> historyData;
	
}
