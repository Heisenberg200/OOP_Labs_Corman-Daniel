package Staff;

public class Receptionist extends FrontDescStaff {

}
