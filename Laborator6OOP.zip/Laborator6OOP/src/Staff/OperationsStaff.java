package Staff;
import Main.Patient;
import java.util.ArrayList;

public class OperationsStaff extends Staff {
    public ArrayList<Patient> patients;
}