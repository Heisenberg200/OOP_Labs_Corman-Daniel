package Hospital;

import java.util.ArrayList;
import Staff.Staff;
public class Department {
	  public ArrayList<Staff> staff;
}
