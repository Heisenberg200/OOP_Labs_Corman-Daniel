package Utils;

import java.util.Date;

public class HistoryData {
	public String sicknessName;
    public Date date;
    public String recommendations;
}
