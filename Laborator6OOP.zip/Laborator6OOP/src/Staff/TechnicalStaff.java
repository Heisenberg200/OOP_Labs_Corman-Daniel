package Staff;

public class TechnicalStaff extends Staff{

}
